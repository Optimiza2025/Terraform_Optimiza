package optimiza.backend.Domain

enum class StatusCandidato {
    Banco_de_talentos,
    Contratado
}