package optimiza.backend.Domain

enum class EtapaVaga {
    Vaga_aberta,
    Aprovacao_RH,
    Entrevista_candidatos,
    Admissao_concluida
}
