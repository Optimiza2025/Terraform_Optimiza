package optimiza.backend.Domain

enum class StatusCandidatura {
    em_analise,
    aprovado,
    reprovado
}