package optimiza.backend.Domain

enum class StatusVaga {
    ativa,
    concluida,
    encerrada
}