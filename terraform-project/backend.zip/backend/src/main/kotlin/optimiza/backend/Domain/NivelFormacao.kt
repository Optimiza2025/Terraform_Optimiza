package optimiza.backend.Domain

enum class NivelFormacao {
    Ensino_Fundamental_completo,
    Ensino_Medio_incompleto,
    Ensino_Medio_completo,
    Ensino_Superior_cursando,
    Ensino_Superior_completo,
    Pos_graduacao,
    Mestrado,
    Doutorado
}